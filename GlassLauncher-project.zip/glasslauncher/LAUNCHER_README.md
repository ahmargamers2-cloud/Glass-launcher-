# Glass Launcher (iOS 26 style Liquid Glass launcher for Android)

Built on top of **LiquidGlass for Android** by pandadog (MIT licence, see LICENSE).
New module: `launcher/` (applicationId `com.liquidglass.launcher`, minSdk 24 -> Android 8 OK).

## Features
- Glass app icons (iOS-style rounded tile, gloss, rim highlight) + notification badges
- Home pages, glass clock/date widget, glass Dock (long-press icon: App info / Add-Remove Dock / Uninstall)
- App Library (categories) + category overlay, glass Spotlight-style search
- Control Center (swipe down from top-RIGHT, just below the status bar): Wi-Fi, Bluetooth, airplane, mobile data,
  rotation lock, Focus/DND, flashlight, brightness, volume, media controls, battery, timer/calculator/camera/settings
- Notification Center (swipe down from top-LEFT): needs "Notification access"; glass cards, tap to open, x to clear
- Glass banner for new notifications while launcher is open
- Long-press empty space: change wallpaper, notification access, system-settings permission, default home app
- Swipe down elsewhere on home pages: search

## Build (no Android Studio needed)
Push this repo to GitHub -> Actions tab -> "Build Glass Launcher APK" -> download artifact `GlassLauncher-apk`.
Or locally: `./gradlew :launcher:assembleDebug`

## Notes
- The *system* notification shade / status bar can't be restyled by a launcher; this launcher has its own glass
  Notification Center and Control Center.
- Android < 12: blur runs on the CPU/NEON pipeline of the library; Android 13+ gets the full AGSL lens refraction.
