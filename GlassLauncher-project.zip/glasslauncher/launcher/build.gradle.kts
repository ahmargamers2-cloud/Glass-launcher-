plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.liquidglass.launcher"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.liquidglass.launcher"
        minSdk = 24          // Android 8 (API 26) pe bhi chalta hai
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {
    implementation(project(":liquidglass"))
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.viewpager2)
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
