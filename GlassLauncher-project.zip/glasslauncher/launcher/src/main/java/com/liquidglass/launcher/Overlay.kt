package com.liquidglass.launcher

import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import kotlin.math.abs

/** LauncherActivity jo cheezein overlays/pages ko deta hai. */
interface Host {
    val backdrop: View            // wallpaper + pages (glass iske upar capture karta hai)
    val wallpaperView: View       // sirf wallpaper
    val insetTop: Int
    val insetBottom: Int
    fun launch(e: AppEntry, anchor: View)
    fun showAppMenu(e: AppEntry, anchor: View, inDock: Boolean)
    fun showHomeMenu(rawX: Float, rawY: Float)
    fun openCategory(cat: Cat, apps: List<AppEntry>)
    fun openSearch()
    fun allApps(): List<AppEntry>
    fun badgeFor(pkg: String): Int
    fun toast(msg: String)
    fun startSafe(intent: android.content.Intent)
    fun closeOverlays()
}

/** Full-screen overlay: scrim + content, fade in/out, swipe-up se band. */
abstract class Overlay(ctx: Context) : FrameLayout(ctx) {

    protected val scrim = View(ctx).apply { setBackgroundColor(0x66000000) }
    var isOpen = false
        private set

    private val swipe = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (e1 == null) return false
            val dy = e2.y - e1.y
            val dx = e2.x - e1.x
            if (dy < -dpi(60f) && abs(dy) > abs(dx) * 1.5f && vy < -700f) {
                close()
                return true
            }
            return false
        }
    })

    init {
        visibility = GONE
        isClickable = true
        addView(scrim, LayoutParams(MATCH, MATCH))
        scrim.setOnClickListener { close() }
    }

    open fun onOpen() {}
    open fun onClosing() {}
    open fun onClosed() {}

    fun open() {
        if (isOpen) return
        isOpen = true
        animate().cancel()
        alpha = 0f
        visibility = VISIBLE
        onOpen()
        animate().alpha(1f).setDuration(220).start()
    }

    fun close() {
        if (!isOpen) return
        isOpen = false
        onClosing()
        animate().cancel()
        animate().alpha(0f).setDuration(170).withEndAction {
            if (!isOpen) {
                visibility = GONE
                onClosed()
            }
        }.start()
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        swipe.onTouchEvent(ev)
        return false
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        swipe.onTouchEvent(event)
        return true
    }
}

/** Root frame: swipe-down gesture detect karta hai (children ko touch milta rehta hai). */
class GestureFrame(ctx: Context) : FrameLayout(ctx) {

    var onSwipeDown: ((Float, Float) -> Unit)? = null

    private val det = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (e1 == null) return false
            val dy = e2.y - e1.y
            val dx = e2.x - e1.x
            if (dy > dpi(70f) && abs(dy) > abs(dx) * 1.5f && vy > 700f) {
                onSwipeDown?.invoke(e1.x, e1.y)
                return true
            }
            return false
        }
    })

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        det.onTouchEvent(ev)
        return false
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        det.onTouchEvent(event)
        return true
    }
}
