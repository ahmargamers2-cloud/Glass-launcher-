package com.liquidglass.launcher

import android.content.ComponentName
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.UserHandle
import android.os.UserManager

enum class Cat(val title: String) {
    SOCIAL("Social"),
    ENTERTAINMENT("Entertainment"),
    PRODUCTIVITY("Productivity"),
    UTILITIES("Utilities"),
    OTHER("Other")
}

class AppEntry(
    val component: ComponentName,
    val user: UserHandle,
    val label: String,
    val cat: Cat,
    private val info: LauncherActivityInfo
) {
    val pkg: String get() = component.packageName
    val key: String = component.flattenToString() + "#" + user.hashCode()
    val icon: Drawable by lazy { info.getBadgedIcon(0) }
}

object AppRepository {

    fun load(ctx: Context): List<AppEntry> {
        val la = ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        val um = ctx.getSystemService(Context.USER_SERVICE) as UserManager
        val pm = ctx.packageManager
        val out = ArrayList<AppEntry>()
        for (user in um.userProfiles) {
            val list: List<LauncherActivityInfo> = try {
                la.getActivityList(null, user)
            } catch (e: Exception) {
                emptyList()
            }
            for (info in list) {
                val cn = info.componentName
                if (cn.packageName == ctx.packageName) continue
                out.add(AppEntry(cn, user, info.label.toString(), categorize(pm, cn.packageName), info))
            }
        }
        out.sortBy { it.label.lowercase() }
        return out
    }

    private val social = listOf(
        "whatsapp", "instagram", "facebook", "telegram", "snapchat", "twitter", "discord",
        "reddit", "linkedin", "tiktok", "messenger", "signal", "pinterest", "threads", "mms", "messaging"
    )
    private val entertainment = listOf(
        "youtube", "netflix", "spotify", "music", "video", "game", "player", "hotstar", "prime",
        "gallery", "photos", "camera", "movie", "tv", "radio", "podcast"
    )
    private val utilities = listOf(
        "calculator", "clock", "settings", "contacts", "dialer", "phone", "files", "filemanager",
        "calendar", "weather", "compass", "flashlight", "recorder", "vending", "launcher"
    )

    private fun categorize(pm: PackageManager, pkg: String): Cat {
        val p = pkg.lowercase()
        if (social.any { p.contains(it) }) return Cat.SOCIAL
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                val c = pm.getApplicationInfo(pkg, 0).category
                when (c) {
                    ApplicationInfo.CATEGORY_SOCIAL -> return Cat.SOCIAL
                    ApplicationInfo.CATEGORY_GAME,
                    ApplicationInfo.CATEGORY_AUDIO,
                    ApplicationInfo.CATEGORY_VIDEO,
                    ApplicationInfo.CATEGORY_IMAGE -> return Cat.ENTERTAINMENT
                    ApplicationInfo.CATEGORY_PRODUCTIVITY,
                    ApplicationInfo.CATEGORY_NEWS -> return Cat.PRODUCTIVITY
                    ApplicationInfo.CATEGORY_MAPS -> return Cat.UTILITIES
                    else -> {}
                }
            } catch (e: Exception) {
                // ignore, heuristics below
            }
        }
        if (entertainment.any { p.contains(it) }) return Cat.ENTERTAINMENT
        if (utilities.any { p.contains(it) }) return Cat.UTILITIES
        if (p.contains("office") || p.contains("docs") || p.contains("mail") || p.contains("drive") ||
            p.contains("notes") || p.contains("keep") || p.contains("slack") || p.contains("teams") ||
            p.contains("zoom") || p.contains("meet")
        ) return Cat.PRODUCTIVITY
        return Cat.OTHER
    }
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("glass_launcher", Context.MODE_PRIVATE)

    fun dock(c: Context): List<String> =
        (sp(c).getString("dock", "") ?: "").split("|").filter { it.isNotEmpty() }

    fun setDock(c: Context, list: List<String>) {
        sp(c).edit().putString("dock", list.joinToString("|")).apply()
    }
}
