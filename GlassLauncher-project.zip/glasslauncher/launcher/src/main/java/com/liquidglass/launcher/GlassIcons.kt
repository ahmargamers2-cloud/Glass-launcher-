package com.liquidglass.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.View
import java.util.concurrent.Executors
import kotlin.math.min

/** Icon ko iOS-26 jaise glass tile me render karta hai (software bitmap, anti-aliased). */
object GlassIconRenderer {

    fun padFor(iconPx: Int): Int = (iconPx * 0.1f).toInt()

    fun render(entry: AppEntry, iconPx: Int): Bitmap {
        val pad = padFor(iconPx)
        val total = iconPx + pad * 2
        val bmp = Bitmap.createBitmap(total, total, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val s = iconPx.toFloat()
        val r = s * 0.225f

        // 1) soft drop shadow
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x55000000
            maskFilter = BlurMaskFilter(pad * 0.7f + 1f, BlurMaskFilter.Blur.NORMAL)
        }
        c.drawRoundRect(
            RectF(pad.toFloat(), pad + pad * 0.45f, pad + s, pad + s + pad * 0.45f),
            r, r, shadow
        )

        // 2) icon content (clip karne ke liye alag layer jaisa bitmap)
        val tile = Bitmap.createBitmap(iconPx, iconPx, Bitmap.Config.ARGB_8888)
        val tc = Canvas(tile)

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, 0f, s, 0xFF5B6475.toInt(), 0xFF2E3442.toInt(), Shader.TileMode.CLAMP)
        }
        val d = entry.icon
        if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
            tc.drawRect(0f, 0f, s, s, bgPaint)
            val off = (iconPx * 0.25f).toInt()   // 108dp layer, 72dp visible => 25% bleed
            val bg = d.background
            val fg = d.foreground
            if (bg != null) {
                bg.setBounds(-off, -off, iconPx + off, iconPx + off)
                bg.draw(tc)
            }
            if (fg != null) {
                fg.setBounds(-off, -off, iconPx + off, iconPx + off)
                fg.draw(tc)
            }
        } else {
            tc.drawRect(0f, 0f, s, s, bgPaint)
            val inset = (iconPx * 0.15f).toInt()
            d.setBounds(inset, inset, iconPx - inset, iconPx - inset)
            d.draw(tc)
        }

        // 3) glass gloss: upar se halka white, neeche halka dark
        val gloss = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, 0f, s * 0.55f, 0x66FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        }
        tc.drawRect(0f, 0f, s, s * 0.55f, gloss)
        val shade = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, s * 0.5f, 0f, s, 0x00000000, 0x30000000, Shader.TileMode.CLAMP)
        }
        tc.drawRect(0f, s * 0.5f, s, s, shade)

        // 4) rounded mask (DST_IN) => anti-aliased edges
        val mask = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        tc.drawRoundRect(RectF(0f, 0f, s, s), r, r, mask)

        c.drawBitmap(tile, pad.toFloat(), pad.toFloat(), null)
        tile.recycle()

        // 5) rim highlight (glass kinara)
        val sw = (s * 0.025f).coerceAtLeast(1.2f)
        val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = sw
            shader = LinearGradient(
                pad.toFloat(), pad.toFloat(), pad + s, pad + s,
                intArrayOf(0xE6FFFFFF.toInt(), 0x1AFFFFFF, 0x66FFFFFF),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        c.drawRoundRect(
            RectF(pad + sw / 2f, pad + sw / 2f, pad + s - sw / 2f, pad + s - sw / 2f),
            r - sw / 2f, r - sw / 2f, rim
        )
        return bmp
    }
}

/** Background thread pe icons render karke cache karta hai. Sab access main thread se. */
object IconCache {
    private val cache = HashMap<String, Bitmap>()
    private val waiters = HashMap<String, LinkedHashSet<() -> Unit>>()
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun request(entry: AppEntry, iconPx: Int, onReady: () -> Unit): Bitmap? {
        val k = entry.key + "@" + iconPx
        cache[k]?.let { return it }
        val set = waiters[k]
        if (set != null) {
            set.add(onReady)
            return null
        }
        waiters[k] = linkedSetOf(onReady)
        exec.execute {
            val bmp: Bitmap = try {
                GlassIconRenderer.render(entry, iconPx)
            } catch (t: Throwable) {
                Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
            }
            main.post {
                cache[k] = bmp
                waiters.remove(k)?.forEach { it() }
            }
        }
        return null
    }
}

/** Ek app icon + label + notification badge. */
class AppIconView(ctx: Context) : View(ctx) {

    var entry: AppEntry? = null
        set(v) {
            field = v
            labelText = v?.label ?: ""
            invalidate()
        }
    var showLabel = true
    var iconDp = 60f
    var badge = 0
        set(v) {
            field = v
            invalidate()
        }

    private var labelText: CharSequence = ""
    private val onIconReady: () -> Unit = { invalidate() }

    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = ctx.dp(11.5f)
        setShadowLayer(ctx.dp(3f), 0f, ctx.dp(1f), 0x99000000.toInt())
    }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF3B30.toInt() }
    private val badgeText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = ctx.dp(11f)
        isFakeBoldText = true
    }

    init {
        isClickable = true
        isLongClickable = true
    }

    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        val sc = if (pressed) 0.88f else 1f
        animate().scaleX(sc).scaleY(sc).setDuration(110).start()
    }

    private fun iconPx(): Int = min(dpi(iconDp), width - dpi(6f)).coerceAtLeast(8)

    override fun onDraw(c: android.graphics.Canvas) {
        val e = entry ?: return
        val px = iconPx()
        val cx = width / 2f
        val top = if (showLabel) dp(6f) else (height - px) / 2f

        val bmp = IconCache.request(e, px, onIconReady)
        if (bmp != null) {
            c.drawBitmap(bmp, cx - bmp.width / 2f, top - GlassIconRenderer.padFor(px), bmpPaint)
        }

        if (badge > 0) {
            val br = dp(9f)
            val bx = cx + px / 2f - dp(2f)
            val by = top + dp(2f)
            val txt = if (badge > 99) "99+" else badge.toString()
            val w = if (txt.length > 1) br * 2.4f else br * 2f
            c.drawRoundRect(bx - w / 2f, by - br, bx + w / 2f, by + br, br, br, badgePaint)
            c.drawText(txt, bx, by + badgeText.textSize * 0.35f, badgeText)
        }

        if (showLabel) {
            val avail = (width - dp(4f))
            val t = TextUtils.ellipsize(labelText, android.text.TextPaint(labelPaint), avail, TextUtils.TruncateAt.END)
            c.drawText(t.toString(), cx, top + px + dp(15f), labelPaint)
        }
    }
}
