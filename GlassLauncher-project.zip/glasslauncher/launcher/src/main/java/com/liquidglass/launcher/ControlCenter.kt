package com.liquidglass.launcher

import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Typeface
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.example.liquidglass.LiquidGlassView
import kotlin.math.roundToInt

/** Round/squircle control button (Wi-Fi, flashlight, ...). Active hone pe colour fill. */
class CcButton(ctx: Context, iconRes: Int, private val cornerFraction: Float = 0.5f) : View(ctx) {

    var active = false
        set(v) {
            if (field != v) {
                field = v
                invalidate()
            }
        }
    var activeColor = 0xFF0A84FF.toInt()
    var activeIconColor = Color.WHITE
    var inactiveFill = 0x4D000000
    var iconScale = 0.46f

    private val icon = ctx.getDrawable(iconRes)?.mutate()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = true
    }

    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        val s = if (pressed) 0.92f else 1f
        animate().scaleX(s).scaleY(s).setDuration(100).start()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = minOf(w, h)
        val inset = dp(2f)
        val rect = RectF((w - m) / 2f + inset, (h - m) / 2f + inset, (w + m) / 2f - inset, (h + m) / 2f - inset)
        val color = if (active) activeColor else inactiveFill
        if (color != 0) {
            fill.color = color
            val r = rect.width() * cornerFraction
            c.drawRoundRect(rect, r, r, fill)
        }
        val d = icon ?: return
        val target = m * iconScale
        val iw = d.intrinsicWidth.toFloat().coerceAtLeast(1f)
        val ih = d.intrinsicHeight.toFloat().coerceAtLeast(1f)
        val sc = target / maxOf(iw, ih)
        val dw = (iw * sc).toInt()
        val dh = (ih * sc).toInt()
        val cx = (w / 2f).toInt()
        val cy = (h / 2f).toInt()
        d.setBounds(cx - dw / 2, cy - dh / 2, cx + dw / 2, cy + dh / 2)
        d.setTint(if (active) activeIconColor else Color.WHITE)
        d.draw(c)
    }
}

/** Vertical glass slider (brightness / volume). */
class CcSlider(ctx: Context, iconRes: Int) : View(ctx) {

    var value = 0.5f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var isDragging = false
        private set
    var onChange: ((Float) -> Unit)? = null
    var canStart: (() -> Boolean)? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xF2FFFFFF.toInt() }
    private val mask = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    private val icon = ctx.getDrawable(iconRes)?.mutate()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = dp(28f)
        val sc = c.saveLayer(0f, 0f, w, h, null)
        c.drawRect(0f, h * (1f - value), w, h, fill)
        c.drawRoundRect(RectF(0f, 0f, w, h), r, r, mask)
        c.restoreToCount(sc)

        val d = icon ?: return
        val target = dp(24f)
        val iw = d.intrinsicWidth.toFloat().coerceAtLeast(1f)
        val ih = d.intrinsicHeight.toFloat().coerceAtLeast(1f)
        val s = target / maxOf(iw, ih)
        val dw = (iw * s).toInt()
        val dh = (ih * s).toInt()
        val cx = (w / 2f).toInt()
        val cy = (h - dp(32f)).toInt()
        d.setBounds(cx - dw / 2, cy - dh / 2, cx + dw / 2, cy + dh / 2)
        d.setTint(if (value > 0.14f) 0xFF3A3A3C.toInt() else Color.WHITE)
        d.draw(c)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (canStart?.invoke() == false) {
                    isDragging = false
                    return true
                }
                parent?.requestDisallowInterceptTouchEvent(true)
                isDragging = true
                update(e.y)
            }
            MotionEvent.ACTION_MOVE -> if (isDragging) update(e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> isDragging = false
        }
        return true
    }

    private fun update(y: Float) {
        value = 1f - y / height.toFloat()
        onChange?.invoke(value)
    }
}

/** iOS-style Control Center, liquid glass panels + real controls. */
class ControlCenterView(ctx: Context, private val host: Host) : Overlay(ctx) {

    private val handler = Handler(Looper.getMainLooper())

    private val btnAir = CcButton(ctx, R.drawable.ic_cc_airplane).apply { activeColor = 0xFFFF9500.toInt() }
    private val btnData = CcButton(ctx, R.drawable.ic_cc_cellular).apply { activeColor = 0xFF34C759.toInt() }
    private val btnWifi = CcButton(ctx, R.drawable.ic_cc_wifi)
    private val btnBt = CcButton(ctx, R.drawable.ic_cc_bluetooth)

    private val btnRot = CcButton(ctx, R.drawable.ic_cc_lock_rotation, 0.38f).apply {
        inactiveFill = 0
        activeColor = 0xFFFF3B30.toInt()
    }
    private val btnFocus = CcButton(ctx, R.drawable.ic_cc_moon, 0.38f).apply {
        inactiveFill = 0
        activeColor = 0xFF5E5CE6.toInt()
    }
    private val btnFlash = CcButton(ctx, R.drawable.ic_cc_flashlight, 0.38f).apply {
        inactiveFill = 0
        activeColor = 0xFFFFFFFF.toInt()
        activeIconColor = 0xFF1C1C1E.toInt()
        iconScale = 0.5f
    }

    private val brightness = CcSlider(ctx, R.drawable.ic_cc_sun)
    private val volume = CcSlider(ctx, R.drawable.ic_cc_speaker)

    private val mediaTitle = TextView(ctx).apply {
        setTextColor(Color.WHITE)
        textSize = 15f
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        text = "Not Playing"
    }
    private val mediaArtist = TextView(ctx).apply {
        setTextColor(0xB3FFFFFF.toInt())
        textSize = 13f
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }
    private val mediaPrev = ImageView(ctx).apply { setImageResource(R.drawable.ic_cc_backward) }
    private val mediaPlay = ImageView(ctx).apply { setImageResource(R.drawable.ic_cc_play) }
    private val mediaNext = ImageView(ctx).apply { setImageResource(R.drawable.ic_cc_forward) }
    private var mediaCtl: MediaController? = null
    private var mediaNoAccess = false

    private val batteryText = TextView(ctx).apply {
        setTextColor(Color.WHITE)
        textSize = 16f
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        gravity = Gravity.CENTER
    }

    private val sv = ScrollView(ctx).apply {
        isVerticalScrollBarEnabled = false
        clipToPadding = false
        overScrollMode = OVER_SCROLL_NEVER
    }
    private val content = FrameLayout(ctx)

    private val cam = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private var torchId: String? = null
    private var torchOn = false
    private var torchRegistered = false
    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchId) {
                torchOn = enabled
                btnFlash.active = enabled
            }
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (isOpen) {
                refresh()
                handler.postDelayed(this, 1000)
            }
        }
    }

    init {
        build()
        addView(sv, LayoutParams(MATCH, MATCH))
        sv.setOnClickListener { close() }
        wire()
    }

    fun setInsets(top: Int, bottom: Int) {
        sv.setPadding(0, top + dpi(24f), 0, bottom + dpi(24f))
    }

    // ---------------------------------------------------------------- layout

    private fun build() {
        val sw = resources.displayMetrics.widthPixels
        val pad = dpi(18f)
        val gap = dpi(12f)
        val u = (sw - 2 * pad - 3 * gap) / 4
        fun span(n: Int) = n * u + (n - 1) * gap
        fun add(v: View, col: Int, row: Int, cs: Int, rs: Int) {
            content.addView(
                v,
                FrameLayout.LayoutParams(span(cs), span(rs)).apply {
                    leftMargin = pad + col * (u + gap)
                    topMargin = row * (u + gap)
                }
            )
        }

        // --- connectivity 2x2
        val conn = glassPanel(context, host.backdrop, 30f)
        val cp = dpi(14f)
        val cd = (span(2) - 3 * cp) / 2
        fun place(b: CcButton, cx: Int, cy: Int) {
            conn.addView(b, FrameLayout.LayoutParams(cd, cd).apply {
                leftMargin = cp + cx * (cd + cp)
                topMargin = cp + cy * (cd + cp)
            })
        }
        place(btnAir, 0, 0)
        place(btnData, 1, 0)
        place(btnWifi, 0, 1)
        place(btnBt, 1, 1)
        add(conn, 0, 0, 2, 2)

        // --- media 2x2
        val media = glassPanel(context, host.backdrop, 30f)
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(cp, cp, cp, cp)
        }
        col.addView(ImageView(context).apply {
            setImageResource(R.drawable.ic_cc_music_note)
            alpha = 0.75f
        }, LinearLayout.LayoutParams(dpi(18f), dpi(18f)))
        col.addView(View(context), LinearLayout.LayoutParams(MATCH, dpi(6f)))
        col.addView(mediaTitle, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(mediaArtist, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(View(context), LinearLayout.LayoutParams(MATCH, 0, 1f))
        val controls = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        for (iv in listOf(mediaPrev, mediaPlay, mediaNext)) {
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            iv.setPadding(dpi(8f), dpi(6f), dpi(8f), dpi(6f))
            iv.setColorFilter(Color.WHITE)
            controls.addView(iv, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
        col.addView(controls, LinearLayout.LayoutParams(MATCH, dpi(40f)))
        media.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        add(media, 2, 0, 2, 2)

        // --- small tiles
        fun tile(b: CcButton): LiquidGlassView {
            val g = glassPanel(context, host.backdrop, 28f)
            g.addView(b, FrameLayout.LayoutParams(MATCH, MATCH).apply {
                val m = dpi(6f)
                setMargins(m, m, m, m)
            })
            return g
        }
        add(tile(btnRot), 0, 2, 1, 1)
        add(tile(btnFocus), 1, 2, 1, 1)
        add(tile(btnFlash), 0, 3, 1, 1)

        // --- battery tile
        val bat = glassPanel(context, host.backdrop, 28f)
        val bl = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        bl.addView(ImageView(context).apply {
            setImageResource(R.drawable.ic_cc_battery)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(dpi(30f), dpi(20f)))
        bl.addView(batteryText, LinearLayout.LayoutParams(WRAP, WRAP))
        bat.addView(bl, FrameLayout.LayoutParams(MATCH, MATCH))
        add(bat, 1, 3, 1, 1)

        // --- sliders
        val bPanel = glassPanel(context, host.backdrop, 28f)
        bPanel.addView(brightness, FrameLayout.LayoutParams(MATCH, MATCH))
        add(bPanel, 2, 2, 1, 2)
        val vPanel = glassPanel(context, host.backdrop, 28f)
        vPanel.addView(volume, FrameLayout.LayoutParams(MATCH, MATCH))
        add(vPanel, 3, 2, 1, 2)

        // --- shortcuts bar
        val bar = glassPanel(context, host.backdrop, 30f)
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dpi(8f), dpi(8f), dpi(8f), dpi(8f))
        }
        val shortcuts: List<Pair<Int, () -> Unit>> = listOf(
            R.drawable.ic_cc_timer to { openTimer() },
            R.drawable.ic_cc_calculator to { openCalculator() },
            R.drawable.ic_cc_camera to { openCamera() },
            R.drawable.ic_cc_settings to { go(Intent(Settings.ACTION_SETTINGS)) }
        )
        for (s in shortcuts) {
            val b = CcButton(context, s.first).apply {
                inactiveFill = 0x33000000
                iconScale = 0.44f
                setOnClickListener { s.second() }
            }
            row.addView(b, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
        bar.addView(row, FrameLayout.LayoutParams(MATCH, MATCH))
        add(bar, 0, 4, 4, 1)

        sv.addView(content, FrameLayout.LayoutParams(MATCH, span(1) * 5 + gap * 4))
    }

    // ---------------------------------------------------------------- actions

    private fun wire() {
        btnAir.setOnClickListener { go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
        btnData.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 29) go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            else go(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        }
        btnWifi.setOnClickListener { toggleWifi() }
        btnBt.setOnClickListener { toggleBluetooth() }
        btnRot.setOnClickListener { toggleRotation() }
        btnFocus.setOnClickListener { toggleFocus() }
        btnFlash.setOnClickListener { toggleTorch() }

        brightness.canStart = { ensureWrite() }
        brightness.onChange = { v ->
            try {
                val cr = context.contentResolver
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, (v * 255f).roundToInt().coerceIn(1, 255))
            } catch (e: Exception) {
            }
        }
        volume.onChange = { v ->
            try {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, (v * max).roundToInt(), 0)
            } catch (e: Exception) {
            }
        }

        mediaPrev.setOnClickListener { mediaCtl?.transportControls?.skipToPrevious() }
        mediaNext.setOnClickListener { mediaCtl?.transportControls?.skipToNext() }
        mediaPlay.setOnClickListener {
            val mc = mediaCtl
            if (mc == null) {
                if (mediaNoAccess) go(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } else {
                if (mc.playbackState?.state == PlaybackState.STATE_PLAYING) mc.transportControls.pause()
                else mc.transportControls.play()
                handler.postDelayed({ refresh() }, 350)
            }
        }
    }

    private fun go(intent: Intent) {
        host.closeOverlays()
        host.startSafe(intent)
    }

    private fun ensureWrite(): Boolean {
        if (Settings.System.canWrite(context)) return true
        host.toast("Brightness ke liye 'Modify system settings' allow karo")
        go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + context.packageName)))
        return false
    }

    private fun toggleWifi() {
        if (Build.VERSION.SDK_INT < 29) {
            try {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                wm.isWifiEnabled = !wm.isWifiEnabled
                handler.postDelayed({ refresh() }, 700)
            } catch (e: Exception) {
                go(Intent(Settings.ACTION_WIFI_SETTINGS))
            }
        } else {
            go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
        }
    }

    private fun toggleBluetooth() {
        if (Build.VERSION.SDK_INT < 31) {
            try {
                val a = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                if (a != null) {
                    if (a.isEnabled) a.disable() else a.enable()
                    handler.postDelayed({ refresh() }, 700)
                    return
                }
            } catch (e: Exception) {
            }
        }
        go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    }

    private fun toggleRotation() {
        if (!ensureWrite()) return
        try {
            val cr = context.contentResolver
            val locked = Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
            Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, if (locked) 1 else 0)
            refresh()
        } catch (e: Exception) {
        }
    }

    private fun toggleFocus() {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) {
            val on = focusOn(nm)
            nm.setInterruptionFilter(
                if (on) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
            )
            handler.postDelayed({ refresh() }, 300)
        } else {
            host.toast("Do Not Disturb access allow karo")
            go(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
    }

    private fun toggleTorch() {
        val id = torchId
        if (id == null) {
            host.toast("Flashlight available nahi hai")
            return
        }
        try {
            cam.setTorchMode(id, !torchOn)
        } catch (e: Exception) {
            host.toast("Flashlight on nahi ho paaya")
        }
    }

    private fun openTimer() {
        val i = if (Build.VERSION.SDK_INT >= 26) Intent(AlarmClock.ACTION_SHOW_TIMERS) else Intent(AlarmClock.ACTION_SHOW_ALARMS)
        go(i)
    }

    private fun openCalculator() {
        go(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
    }

    private fun openCamera() {
        go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
    }

    // ---------------------------------------------------------------- state

    override fun onOpen() {
        torchId = try {
            cam.cameraIdList.firstOrNull { id ->
                val ch = cam.getCameraCharacteristics(id)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                        ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        } catch (e: Exception) {
            null
        }
        try {
            cam.registerTorchCallback(torchCb, handler)
            torchRegistered = true
        } catch (e: Exception) {
        }
        refresh()
        sv.scrollTo(0, 0)
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, 1000)
    }

    override fun onClosed() {
        handler.removeCallbacks(ticker)
        if (torchRegistered) {
            try {
                cam.unregisterTorchCallback(torchCb)
            } catch (e: Exception) {
            }
            torchRegistered = false
        }
    }

    fun refresh() {
        btnAir.active = airplaneOn()
        btnData.active = dataOn()
        btnWifi.active = wifiOn()
        btnBt.active = btOn()
        btnRot.active = rotationLocked()
        btnFocus.active = focusOn(context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
        btnFlash.active = torchOn

        try {
            val cr = context.contentResolver
            if (!brightness.isDragging) {
                brightness.value = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f
            }
            if (!volume.isDragging) {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                volume.value = am.getStreamVolume(AudioManager.STREAM_MUSIC) / max.toFloat()
            }
        } catch (e: Exception) {
        }

        batteryText.text = batteryPercent().let { if (it >= 0) "$it%" else "--" }
        refreshMedia()
    }

    private fun wifiOn(): Boolean = try {
        (context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) {
        false
    }

    private fun btOn(): Boolean = try {
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true
    } catch (e: Exception) {
        false
    }

    private fun airplaneOn(): Boolean = try {
        Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
    } catch (e: Exception) {
        false
    }

    private fun dataOn(): Boolean = try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
    } catch (e: Exception) {
        false
    }

    private fun rotationLocked(): Boolean = try {
        Settings.System.getInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
    } catch (e: Exception) {
        false
    }

    private fun focusOn(nm: NotificationManager): Boolean {
        val f = nm.currentInterruptionFilter
        return f != NotificationManager.INTERRUPTION_FILTER_ALL && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }

    private fun batteryPercent(): Int {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (level < 0 || scale <= 0) -1 else level * 100 / scale
    }

    private fun refreshMedia() {
        mediaNoAccess = false
        var mc: MediaController? = null
        try {
            val msm = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(context, GlassNotificationService::class.java))
            mc = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
        } catch (e: SecurityException) {
            mediaNoAccess = true
        } catch (e: Exception) {
        }
        mediaCtl = mc
        if (mc == null) {
            mediaTitle.text = if (mediaNoAccess) "Enable access" else "Not Playing"
            mediaArtist.text = if (mediaNoAccess) "Tap play to allow media info" else ""
            mediaPlay.setImageResource(R.drawable.ic_cc_play)
        } else {
            val md = mc.metadata
            mediaTitle.text = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Playing"
            mediaArtist.text = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
            val playing = mc.playbackState?.state == PlaybackState.STATE_PLAYING
            mediaPlay.setImageResource(if (playing) R.drawable.ic_cc_pause else R.drawable.ic_cc_play)
        }
    }
}
